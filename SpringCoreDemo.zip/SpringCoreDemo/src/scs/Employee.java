package scs;

public class Employee {
private int empid;
private String empname;
Dept d;
Employee()
{
	System.out.println("Employee ID is "+empid);
}
Employee(int empid)
{
	this.empid=empid;
}
Employee(int empid, String empname, Dept d)
{
	this.empid=empid;
	this.empname=empname;
	this.d=d;
}
public void show()
{
	System.out.println("Employee ID is "+empid + "Employee name is "+empname + " dept info is "+d);
}
}

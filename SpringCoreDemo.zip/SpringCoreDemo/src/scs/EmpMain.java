package scs;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class EmpMain {

	public static void main(String[] args) {
		Resource r=new ClassPathResource("applicationContext.xml");  
        BeanFactory be = new XmlBeanFactory(r);
        Employee e = (Employee) be.getBean("e");
        e.show();
	}

}

package scs;

public class Dept {
private int deptid;
private String deptname;
Dept(int deptid,String deptname)
{
	this.deptid = deptid;
	this.deptname = deptname;
}
public String toString()
{
	return "Deptid is "+deptid + " deptname is "+deptname;
}
}

package uao;

import java.applet.AppletContext;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import dao.SI;
import bao.SILogic;

public class AccessSI {

	public static void main(String[] args) {
		//Resource res = new ClassPathResource("applicationContext.xml");
		
		
		//BeanFactory bean = new XmlBeanFactory(res);
		ApplicationContext bean = 
		new ClassPathXmlApplicationContext("applicationContext.xml");
		SI s = (SI)bean.getBean("sibean");
		float r = new SILogic().calcSI(s.getP(),s.getR(),s.getT());
		System.out.print("Result is "+r);

	}

}
